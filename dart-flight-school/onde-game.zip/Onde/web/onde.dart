import 'dart:html';
import 'dart:math';

var indexPremiado = "";
var numeroDeQuadros = 6;
var numeroClicks = 0;
var clickLiberado = true;

main() {
  ButtonElement button = querySelector('#novoBtn');
  button.onClick.listen( (event) => configuraTabuleiro() );
}

realizaSorteio(){
  clickLiberado = true;
  numeroClicks = 0;
  indexPremiado = new Random().nextInt(numeroDeQuadros).toString();
}

configuraTabuleiro(){
  realizaSorteio(); 
  
  UListElement tabuleiro = querySelector('#tabuleiro');
  tabuleiro.children.clear();
  for(int i=0; i< numeroDeQuadros; i++){
    tabuleiro.children.add( criarElementoJogo(i) );
  }
}

LIElement criarElementoJogo(int index) => new LIElement()
  ..classes.add('item')
  ..setAttribute('data-index', index.toString())
  ..onClick.listen(verificaJogada)
  ..children.add( 
      new Element.tag('p')
      ..text = '.');

verificaJogada(MouseEvent event) {
  if(!clickLiberado){ return;}
  
  var palpite = event.currentTarget.getAttribute('data-index');
  numeroClicks++;
  
  if(palpite == indexPremiado){
    configuraPalpite(event.currentTarget);
    finalizarJogo("Você ganhou");
  } else{
    configuraPalpite(event.currentTarget, ganhou: false);
    if(numeroClicks >= 2){
      finalizarJogo("Você Perdeu");
    }
  }
}

configuraPalpite(Element elementoPalpite, {bool ganhou: true }) {
  if(ganhou){
    elementoPalpite
      ..classes.add("item-acertou")
      ..firstChild.text = "parabéns" ;
  }else{
    elementoPalpite
      ..classes.add("item-aberto")
      ..firstChild.text = "ops" ;
  }
}

finalizarJogo(String mensagem){
  querySelector('#mensagem').text = mensagem;
  clickLiberado = false;
}
